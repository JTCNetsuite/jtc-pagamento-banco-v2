/**
 * @NApiVersion 2.1
 * @NModuleScope public
 */
define(["require", "exports", "N/log", "N/search", "../module/jtc_pagamento_banco_bb_CTS"], function (require, exports, log, search, jtc_pagamento_banco_bb_CTS_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    var getInputData = function () {
        try {
            var response_1 = [];
            var invoiceRecord = search.create({
                type: search.Type.INVOICE,
                filters: [
                    [jtc_pagamento_banco_bb_CTS_1.constante.INVOICE.STATUS, search.Operator.IS, 2],
                    "AND",
                    ["mainline", search.Operator.IS, "T"]
                ],
                columns: [
                    search.createColumn({ name: jtc_pagamento_banco_bb_CTS_1.constante.INVOICE.INTERNALID })
                ]
            }).run().each(function (res) {
                // log.debug('res', res);
                var results = JSON.parse(JSON.stringify(res));
                var idInvoice = String(res.getValue({ name: jtc_pagamento_banco_bb_CTS_1.constante.INVOICE.INTERNALID }));
                // log.debug('idIvoice', idInvoice);
                var cnabInstallSearch = search.create({
                    type: jtc_pagamento_banco_bb_CTS_1.constante.PARCELA_CNAB.ID,
                    filters: [jtc_pagamento_banco_bb_CTS_1.constante.PARCELA_CNAB.TRANSACTION, search.Operator.ANYOF, idInvoice],
                    columns: [
                        search.createColumn({
                            name: jtc_pagamento_banco_bb_CTS_1.constante.PARCELA_CNAB.NOSSO_NUMERO
                        })
                    ]
                }).run().getRange({ start: 0, end: 100 });
                var invoiceObject = {};
                invoiceObject[idInvoice] = [];
                for (var i = 0; cnabInstallSearch.length > i; i++) {
                    invoiceObject[idInvoice].push(cnabInstallSearch[i].getValue({ name: jtc_pagamento_banco_bb_CTS_1.constante.PARCELA_CNAB.NOSSO_NUMERO }));
                }
                response_1.push(invoiceObject);
                return true;
            });
            return response_1;
        }
        catch (e) {
            log.error('jtc_pagamento_banco_bb_mr_MSR.getInputData', e);
        }
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        try {
            log.debug("crtx", ctx.value);
        }
        catch (e) {
            log.error('jtc_pagamento_banco_bb_mr_MSR.map', e);
        }
    };
    exports.map = map;
});
